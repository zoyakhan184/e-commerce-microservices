import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { User, Shield } from "lucide-react"

export function LoginInfo() {
  return (
    <Card className="w-full max-w-md bg-gradient-to-br from-primary/5 to-purple-500/5 border-primary/20">
      <CardHeader>
        <CardTitle className="text-center text-lg">Demo Login Credentials</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-blue-600" />
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              User Account
            </Badge>
          </div>
          <div className="bg-background/50 p-3 rounded-md text-sm">
            <p>
              <strong>Email:</strong> john@example.com
            </p>
            <p>
              <strong>Password:</strong> password123
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-purple-600" />
            <Badge variant="secondary" className="bg-purple-100 text-purple-700">
              Admin Account
            </Badge>
          </div>
          <div className="bg-background/50 p-3 rounded-md text-sm">
            <p>
              <strong>Email:</strong> admin@stylenest.com
            </p>
            <p>
              <strong>Password:</strong> admin123
            </p>
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center pt-2 border-t">
          Use these credentials to test the application features
        </div>
      </CardContent>
    </Card>
  )
}
