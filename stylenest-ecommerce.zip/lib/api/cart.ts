import { apiClient } from "./client"
import type { CartItem } from "@/types"
import { dummyCartItems, dummyProducts } from "@/lib/dummy-data"

export const cartApi = {
  async getCart(userId: string): Promise<CartItem[]> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Return dummy cart items with product details
    return dummyCartItems.map((item) => {
      const product = dummyProducts.find((p) => p.id === item.product_id)
      return {
        ...item,
        product_name: product?.name || item.product_name,
        product_image: product?.imageUrls[0] || item.product_image,
        price: product?.price || item.price,
      }
    })
  },

  addItem: (product_id: string, size: string, color: string, quantity: number) =>
    apiClient.post<{ message: string }>("/api/cart/add", {
      product_id,
      size,
      color,
      quantity,
    }),

  async addToCart(userId: string, productId: string, size: string, color: string, quantity: number): Promise<void> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const product = dummyProducts.find((p) => p.id === productId)
    if (!product) throw new Error("Product not found")

    // Check if item already exists in cart
    const existingItemIndex = dummyCartItems.findIndex(
      (item) => item.product_id === productId && item.size === size && item.color === color,
    )

    if (existingItemIndex >= 0) {
      // Update quantity
      dummyCartItems[existingItemIndex].quantity += quantity
    } else {
      // Add new item
      const newItem: CartItem = {
        product_id: productId,
        product_name: product.name,
        product_image: product.imageUrls[0],
        size,
        color,
        quantity,
        price: product.price,
      }
      dummyCartItems.push(newItem)
    }
  },

  removeItem: (product_id: string) => apiClient.post<{ message: string }>("/api/cart/remove", { product_id }),

  async removeFromCart(userId: string, productId: string): Promise<void> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const index = dummyCartItems.findIndex((item) => item.product_id === productId)
    if (index >= 0) {
      dummyCartItems.splice(index, 1)
    }
  },

  updateQuantity: (product_id: string, quantity: number) =>
    apiClient.post<{ message: string }>("/api/cart/update", {
      product_id,
      quantity,
    }),

  async updateCartItem(userId: string, productId: string, quantity: number): Promise<void> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const item = dummyCartItems.find((item) => item.product_id === productId)
    if (item) {
      item.quantity = quantity
    }
  },
}
