import { apiClient } from "./client"

export const imageApi = {
  uploadImage: (entityId: string, entityType: string, fileType: string, imageData: string) =>
    apiClient.post<{ imageId: string }>("/api/images/upload", {
      entityId,
      entityType,
      fileType,
      imageData,
    }),

  getImage: (imageId: string) => apiClient.get<{ imageData: string; fileType: string }>(`/api/images/${imageId}`),

  deleteImage: (imageId: string) => apiClient.delete<{ status: string }>(`/api/images/${imageId}`),
}
