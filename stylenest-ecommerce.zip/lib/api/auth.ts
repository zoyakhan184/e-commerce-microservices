import type { User } from "@/types"
import { dummyUsers, testCredentials } from "@/lib/dummy-data"

interface AuthResponse {
  token: string
  user: User
}

export const authApi = {
  async login(email: string, password: string): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Check test credentials
    if (email === testCredentials.user.email && password === testCredentials.user.password) {
      const user = dummyUsers.find((u) => u.email === email)
      if (user) {
        return {
          token: "dummy-token-user",
          user,
        }
      }
    }

    if (email === testCredentials.admin.email && password === testCredentials.admin.password) {
      const user = dummyUsers.find((u) => u.email === email)
      if (user) {
        return {
          token: "dummy-token-admin",
          user,
        }
      }
    }

    throw new Error("Invalid credentials")
  },

  async register(name: string, email: string, password: string): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Check if user already exists
    const existingUser = dummyUsers.find((u) => u.email === email)
    if (existingUser) {
      throw new Error("User already exists")
    }

    // Create new user
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      role: "user",
      phone: "",
      gender: "",
      dob: "",
      avatar_url: "",
    }

    dummyUsers.push(newUser)

    return {
      token: `dummy-token-${newUser.id}`,
      user: newUser,
    }
  },

  async validateToken(token: string): Promise<User> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    if (token === "dummy-token-user") {
      const user = dummyUsers.find((u) => u.email === testCredentials.user.email)
      if (user) return user
    }

    if (token === "dummy-token-admin") {
      const user = dummyUsers.find((u) => u.email === testCredentials.admin.email)
      if (user) return user
    }

    throw new Error("Invalid token")
  },
}
