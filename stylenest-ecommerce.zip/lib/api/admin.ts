import { apiClient } from "./client"
import type { AdminDashboard, User, Order, Product, Payment } from "@/types"

export const adminApi = {
  getDashboard: () => apiClient.get<AdminDashboard>("/api/admin/dashboard"),

  getUsers: () => apiClient.get<User[]>("/api/admin/users"),

  deleteUser: (userId: string) => apiClient.delete<{ message: string }>(`/api/admin/users/${userId}`),

  updateUserStatus: (userId: string, status: string) =>
    apiClient.put<{ message: string }>(`/api/admin/users/${userId}/status`, { status }),

  getOrders: () => apiClient.get<Order[]>("/api/admin/orders"),

  updateOrderStatus: (orderId: string, status: string) =>
    apiClient.put<{ message: string }>(`/api/admin/orders/${orderId}/status`, { status }),

  getPayments: () => apiClient.get<Payment[]>("/api/admin/payments"),

  processRefund: (paymentId: string, amount: number) =>
    apiClient.post<{ message: string }>(`/api/admin/payments/${paymentId}/refund`, { amount }),

  addProduct: (product: Omit<Product, "id">) => apiClient.post<{ message: string }>("/api/admin/products/add", product),

  updateProduct: (id: string, product: Partial<Product>) =>
    apiClient.put<{ message: string }>(`/api/admin/products/edit`, { id, ...product }),

  deleteProduct: (id: string) => apiClient.delete<{ message: string }>(`/api/admin/products/delete/${id}`),

  addCategory: (category: { name: string; gender: string; parentId?: string }) =>
    apiClient.post<{ message: string }>("/api/admin/categories/add", category),
}
