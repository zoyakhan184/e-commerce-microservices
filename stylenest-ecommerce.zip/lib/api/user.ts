import { apiClient } from "./client"

export const userApi = {
  getProfile: (userId: string) => apiClient.get<any>(`/api/user/${userId}/profile`),

  updateProfile: (userId: string, profileData: any) =>
    apiClient.put<{ message: string }>(`/api/user/${userId}/profile`, profileData),

  addAddress: (userId: string, address: any) =>
    apiClient.post<{ message: string }>(`/api/user/${userId}/address`, address),

  updateAddress: (addressId: string, address: any) =>
    apiClient.put<{ message: string }>(`/api/user/address/${addressId}`, address),

  getAddresses: (userId: string) => apiClient.get<any[]>(`/api/user/${userId}/addresses`),

  addToWishlist: (userId: string, productId: string) =>
    apiClient.post<{ message: string }>(`/api/user/${userId}/wishlist`, { productId }),

  removeFromWishlist: (userId: string, productId: string) =>
    apiClient.delete<{ message: string }>(`/api/user/${userId}/wishlist/${productId}`),

  getWishlist: (userId: string) => apiClient.get<string[]>(`/api/user/${userId}/wishlist`),
}
