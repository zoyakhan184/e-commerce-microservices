import { apiClient } from "./client"
import type { Product, Category } from "@/types"

export const productsApi = {
  getProducts: (params?: {
    categoryId?: string
    brand?: string
    priceRange?: string
    sortBy?: string
    search?: string
    gender?: string
  }) => {
    const searchParams = new URLSearchParams()
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) searchParams.append(key, value)
      })
    }
    return apiClient.get<Product[]>(`/api/products?${searchParams.toString()}`)
  },

  getProduct: (id: string) => apiClient.get<Product>(`/api/products/${id}`),

  getCategories: () => apiClient.get<Category[]>("/api/categories"),
}
