import type { Product, User, Category, Order, CartItem, Review, AdminDashboard, Payment } from "@/types"

export const testCredentials = {
  user: {
    email: "user@example.com",
    password: "password123",
  },
  admin: {
    email: "admin@example.com",
    password: "admin123",
  },
}

export const dummyUsers: User[] = [
  {
    id: "user-1",
    name: "John Doe",
    email: "user@example.com",
    role: "user",
    phone: "+1 (555) 123-4567",
    gender: "male",
    dob: "1990-01-15",
    avatar_url: "/placeholder.svg?height=100&width=100&text=JD",
  },
  {
    id: "admin-1",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin",
    phone: "+1 (555) 987-6543",
    gender: "female",
    dob: "1985-05-20",
    avatar_url: "/placeholder.svg?height=100&width=100&text=AU",
  },
]

export const dummyOffers = [
  {
    id: "offer-1",
    title: "Summer Sale",
    description: "Up to 70% off on summer collection",
    discount: 70,
    image: "/placeholder.svg?height=200&width=400&text=Summer+Sale+70%25+OFF",
    color: "from-orange-400 to-pink-500",
  },
  {
    id: "offer-2",
    title: "New Arrivals",
    description: "Fresh styles just landed",
    discount: 30,
    image: "/placeholder.svg?height=200&width=400&text=New+Arrivals+30%25+OFF",
    color: "from-purple-400 to-blue-500",
  },
  {
    id: "offer-3",
    title: "Flash Deal",
    description: "Limited time offer on premium brands",
    discount: 50,
    image: "/placeholder.svg?height=200&width=400&text=Flash+Deal+50%25+OFF",
    color: "from-green-400 to-teal-500",
  },
]

export const dummyProducts: Product[] = [
  {
    id: "prod-1",
    name: "Premium Cotton T-Shirt",
    description: "Ultra-soft premium cotton t-shirt with modern fit. Perfect for casual wear and layering.",
    price: 29.99,
    originalPrice: 39.99,
    brand: "StyleNest",
    categoryId: "cat-1",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Cotton+T-Shirt",
      "/placeholder.svg?height=400&width=400&text=T-Shirt+Back",
      "/placeholder.svg?height=400&width=400&text=T-Shirt+Side",
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "White", "Navy", "Gray"],
  },
  {
    id: "prod-2",
    name: "Elegant Summer Dress",
    description: "Beautiful flowy dress perfect for summer occasions. Lightweight and comfortable fabric.",
    price: 89.99,
    originalPrice: 119.99,
    brand: "FashionForward",
    categoryId: "cat-2",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Summer+Dress",
      "/placeholder.svg?height=400&width=400&text=Dress+Back",
      "/placeholder.svg?height=400&width=400&text=Dress+Detail",
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Floral Pink", "Floral Blue", "Solid Navy"],
  },
  {
    id: "prod-3",
    name: "Classic Denim Jeans",
    description: "Timeless denim jeans with perfect fit. Durable and stylish for everyday wear.",
    price: 79.99,
    originalPrice: 99.99,
    brand: "DenimCo",
    categoryId: "cat-3",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Denim+Jeans",
      "/placeholder.svg?height=400&width=400&text=Jeans+Detail",
      "/placeholder.svg?height=400&width=400&text=Jeans+Back",
    ],
    sizes: ["28", "30", "32", "34", "36"],
    colors: ["Dark Blue", "Light Blue", "Black"],
  },
  {
    id: "prod-4",
    name: "Luxury Silk Blouse",
    description: "Premium silk blouse for elegant occasions. Sophisticated design with attention to detail.",
    price: 149.99,
    originalPrice: 199.99,
    brand: "LuxeFashion",
    categoryId: "cat-4",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Silk+Blouse",
      "/placeholder.svg?height=400&width=400&text=Blouse+Detail",
      "/placeholder.svg?height=400&width=400&text=Blouse+Back",
    ],
    sizes: ["XS", "S", "M", "L"],
    colors: ["White", "Cream", "Black", "Navy"],
  },
  {
    id: "prod-5",
    name: "Kids Cartoon Hoodie",
    description: "Fun and comfortable hoodie for kids. Soft fabric with colorful cartoon designs.",
    price: 39.99,
    originalPrice: 49.99,
    brand: "KidsWear",
    categoryId: "cat-5",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Kids+Hoodie",
      "/placeholder.svg?height=400&width=400&text=Hoodie+Back",
      "/placeholder.svg?height=400&width=400&text=Hoodie+Detail",
    ],
    sizes: ["2T", "3T", "4T", "5T", "6T"],
    colors: ["Blue", "Pink", "Green", "Yellow"],
  },
  {
    id: "prod-6",
    name: "Athletic Sneakers",
    description: "High-performance sneakers for active lifestyle. Comfortable cushioning and durable design.",
    price: 129.99,
    originalPrice: 159.99,
    brand: "SportMax",
    categoryId: "cat-6",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Athletic+Sneakers",
      "/placeholder.svg?height=400&width=400&text=Sneakers+Side",
      "/placeholder.svg?height=400&width=400&text=Sneakers+Sole",
    ],
    sizes: ["7", "8", "9", "10", "11", "12"],
    colors: ["White", "Black", "Blue", "Red"],
  },
  {
    id: "prod-7",
    name: "Designer Handbag",
    description: "Elegant designer handbag for modern women. Premium materials with sophisticated styling.",
    price: 199.99,
    originalPrice: 249.99,
    brand: "LuxeBags",
    categoryId: "cat-7",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Designer+Handbag",
      "/placeholder.svg?height=400&width=400&text=Handbag+Interior",
      "/placeholder.svg?height=400&width=400&text=Handbag+Detail",
    ],
    sizes: ["One Size"],
    colors: ["Black", "Brown", "Tan", "Navy"],
  },
  {
    id: "prod-8",
    name: "Casual Polo Shirt",
    description: "Classic polo shirt for casual and business casual occasions. Comfortable fit and quality fabric.",
    price: 49.99,
    originalPrice: 69.99,
    brand: "ClassicWear",
    categoryId: "cat-8",
    imageUrls: [
      "/placeholder.svg?height=400&width=400&text=Polo+Shirt",
      "/placeholder.svg?height=400&width=400&text=Polo+Detail",
      "/placeholder.svg?height=400&width=400&text=Polo+Back",
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Navy", "Red", "Green"],
  },
]

export const dummyCategories: Category[] = [
  { id: "cat-1", name: "T-Shirts", gender: "men", parentId: undefined },
  { id: "cat-2", name: "Dresses", gender: "women", parentId: undefined },
  { id: "cat-3", name: "Jeans", gender: "men", parentId: undefined },
  { id: "cat-4", name: "Blouses", gender: "women", parentId: undefined },
  { id: "cat-5", name: "Hoodies", gender: "kids", parentId: undefined },
  { id: "cat-6", name: "Sneakers", gender: "men", parentId: undefined },
  { id: "cat-7", name: "Handbags", gender: "women", parentId: undefined },
  { id: "cat-8", name: "Polo Shirts", gender: "men", parentId: undefined },
]

export const dummyCartItems: CartItem[] = [
  {
    product_id: "prod-1",
    product_name: "Premium Cotton T-Shirt",
    product_image: "/placeholder.svg?height=80&width=80&text=T-Shirt",
    size: "M",
    color: "Black",
    quantity: 2,
    price: 29.99,
  },
  {
    product_id: "prod-2",
    product_name: "Elegant Summer Dress",
    product_image: "/placeholder.svg?height=80&width=80&text=Dress",
    size: "S",
    color: "Floral Pink",
    quantity: 1,
    price: 89.99,
  },
]

export const dummyOrders: Order[] = [
  {
    id: "order-1",
    status: "delivered",
    payment_status: "paid",
    total_amount: 149.97,
    created_at: "2024-01-15T10:30:00Z",
    items: [
      {
        product_id: "prod-1",
        product_name: "Premium Cotton T-Shirt",
        quantity: 2,
        price: 29.99,
        size: "M",
        color: "Black",
      },
      {
        product_id: "prod-2",
        product_name: "Elegant Summer Dress",
        quantity: 1,
        price: 89.99,
        size: "S",
        color: "Floral Pink",
      },
    ],
  },
]

export const dummyPayments: Payment[] = [
  {
    id: "pay-1",
    order_id: "order-1",
    user_id: "user-1",
    amount: 149.97,
    gateway: "razorpay",
    status: "success",
    txn_ref: "txn_1234567890",
    created_at: "2024-01-15T10:30:00Z",
  },
]

export const dummyReviews: Review[] = [
  {
    id: "review-1",
    user_id: "user-1",
    user_name: "John Doe",
    product_id: "prod-1",
    rating: 5,
    comment: "Great quality t-shirt! Very comfortable and fits perfectly.",
    created_at: "2024-01-10T09:00:00Z",
  },
]

export const dummyAdminDashboard: AdminDashboard = {
  total_users: 1247,
  total_orders: 3891,
  total_revenue: 127543.89,
  low_stock_items: [
    {
      sku_id: "SKU-001",
      product_id: "prod-3",
      quantity: 3,
    },
  ],
}
